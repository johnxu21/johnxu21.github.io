//============================================================================
// Name        : CD.cpp
// Author      : Quinten Soetens
// Version     :
// Description : This code is written as an example solution for the exercises given in the course
//				 Project Software Engineering for the first year bachelor students at Universiteit Antwerpen
//============================================================================

#include "CD.h"

CD::CD() {
}

CD::~CD() {
}

const string& CD::getArtist() const {
	return _artist;
}

void CD::setArtist(const string& artist) {
	_artist = artist;
}

const string& CD::getCompany() const {
	return _company;
}

void CD::setCompany(const string& company) {
	_company = company;
}

const string& CD::getCountry() const {
	return _country;
}

void CD::setCountry(const string& country) {
	_country = country;
}

double CD::getPrice() const {
	return _price;
}

void CD::setPrice(double price) {
	_price = price;
}

const string& CD::getTitle() const {
	return _title;
}

void CD::setTitle(const string& title) {
	_title = title;
}

int CD::getYear() const {
	return _year;
}

void CD::setYear(int year) {
	this->_year = year;
}

bool CD::isValidYear() {
	return this->_year > 1982; //1982 is the year when the Compact Disc was invented.
}

bool CD::isValidPrice() {
	return this->_price > 0;
}

static inline bool isNotAlphabeticOrSpace(char c)
{
    return !(isalpha(c) || (c == ' '));
}

inline bool CD::isValidString(const string& str) {
	return find_if(str.begin(), str.end(), isNotAlphabeticOrSpace) == str.end();
}

bool CD::isConsistent() {
	return isValidYear() && isValidPrice() && isValidString(this->_artist)
			&& isValidString(this->_title) && isValidString(this->_company)
			&& isValidString(this->_country);
}

