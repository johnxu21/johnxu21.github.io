//============================================================================
// Name        : CDParser.h
// Author      : Quinten Soetens
// Version     :
// Description : This code is written as an example solution for the exercises given in the course
//				 Project Software Engineering for the first year bachelor students at Universiteit Antwerpen
//============================================================================

#ifndef CDPARSER_H_
#define CDPARSER_H_

#include <string>
#include "../CD.h"
#include "AbstractParser.h"
#include "tinyxml/tinyxml.h"

using namespace std;


/*
 * This Parser is a subclass of an AbstractParser, it can therefore load any XML file.
 * However it is meant to parse CD's by using the parseCD method.
 */
class CDParser: public AbstractParser{
private:
	/*
	 * This method looks for the text value in a given tag inside the given element.
	 */
	string readElement(TiXmlElement* elem, const char* tag);
	CD* cd;
public:
	CDParser();
	virtual ~CDParser();

	/*
	 * This method expects the TiXmlElement that is pased as a parameter to represent a CD.
	 * It will then parse said CD and return it as a pointer to a CD object.
	 */
	CD* parseCD(TiXmlElement* elem);

	/*
	 * Returns a pointer to the parsed CD object.
	 */
	CD* getCD();
};

#endif /* CDPARSER_H_ */
