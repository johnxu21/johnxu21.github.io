//============================================================================
// Name        : CDParser.cpp
// Author      : Quinten Soetens
// Version     :
// Description : This code is written as an example solution for the exercises given in the course
//				 Project Software Engineering for the first year bachelor students at Universiteit Antwerpen
//============================================================================

#include "CDParser.h"

CDParser::CDParser() {
	cd = new CD();
}

CDParser::~CDParser() {
}

string CDParser::readElement(TiXmlElement* elem, const char* tag) {
	TiXmlElement* e = elem->FirstChildElement(tag);
	TiXmlNode* node = e->FirstChild();
	TiXmlText* text = node->ToText();
	return text->Value();
}

CD* CDParser::parseCD(TiXmlElement* elem) {
	string title = readElement(elem, "TITLE");
	cd->setTitle(title);
	string artist = readElement(elem, "ARTIST");
	cd->setArtist(artist);
	string company = readElement(elem, "COMPANY");
	cd->setCompany(company);
	string country = readElement(elem, "COUNTRY");
	cd->setCountry(country);

	string year = readElement(elem, "YEAR");
	cd->setYear(atoi(year.c_str()));
	string price = readElement(elem, "PRICE");
	cd->setPrice(atof(price.c_str()));

	return cd;
}

CD* CDParser::getCD(){
	return cd;
}
