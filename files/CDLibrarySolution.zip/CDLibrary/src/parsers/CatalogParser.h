//============================================================================
// Name        : CatalogueParser.h
// Author      : Quinten Soetens
// Version     :
// Description : This code is written as an example solution for the exercises given in the course
//				 Project Software Engineering for the first year bachelor students at Universiteit Antwerpen
//============================================================================

#ifndef CATALOGUEPARSER_H_
#define CATALOGUEPARSER_H_

#include <vector>
#include <string>
#include "../CD.h"
#include "AbstractParser.h"
#include "CDParser.h"
#include "tinyxml/tinyxml.h"


using namespace std;

/*
 * This Parser is a subclass of an AbstractParser, it can therefore load any XML file.
 * However it is meant to parse Catalogs by using the parseCatalog method.
 */
class CatalogParser: public AbstractParser{
private:
	vector<CD*>* catalog;

public:
	CatalogParser();
	virtual ~CatalogParser();

	/*
	 * This method expects the TiXmlElement that is passed as a parameter to represent an entire catalog of CDs.
	 * It will then parse said catalog and return it as a pointer to a vector of CD*'s.
	 */
	vector<CD*>* parseCatalog(TiXmlElement* elem);

	/*
	 * Returns a pointer to the parsed vector of CD*'s
	 */
	vector<CD*>* getCatalog();
};

#endif /* CATALOGUEPARSER_H_ */
