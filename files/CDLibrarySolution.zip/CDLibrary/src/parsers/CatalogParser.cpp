//============================================================================
// Name        : CatalogueParser.cpp
// Author      : Quinten Soetens
// Version     :
// Description : This code is written as an example solution for the exercises given in the course
//				 Project Software Engineering for the first year bachelor students at Universiteit Antwerpen
//============================================================================

#include "CatalogParser.h"

CatalogParser::CatalogParser() {
	catalog = new vector<CD*>();
}

CatalogParser::~CatalogParser() {
}

vector<CD*>* CatalogParser::parseCatalog(TiXmlElement* elem) {
	for(TiXmlElement* e = elem->FirstChildElement(); e != NULL; e = e->NextSiblingElement()){
		//note that we are explicitly creating a CDParser to parse separate instances of CD's inside this catalog.
		CDParser cdp;
		CD* cd = cdp.parseCD(e);
		if(cd->isConsistent())
			catalog->push_back(cd);
	}

	return catalog;
}

vector<CD*>* CatalogParser::getCatalog() {
	 return catalog;
}
