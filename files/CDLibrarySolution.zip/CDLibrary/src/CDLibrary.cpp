//============================================================================
// Name        : CDLibrary.cpp
// Author      : Quinten Soetens
// Version     :
// Description : This code is written as an example solution for the exercises given in the course
//				 Project Software Engineering for the first year bachelor students at Universiteit Antwerpen
//============================================================================

#include <iostream>
#include "parsers/CatalogParser.h"
#include "CD.h"
using namespace std;

/*
 * Main function that can be used to parse and print a catalog of CD's.
 * It takes as argument a string which is the path to the xml file.
 */
int main(int argc, char* argv[]) {
	//TODO verify program arguments
	CatalogParser parser;
	if(parser.loadFile(argv[1])){
		parser.parseCatalog(parser.getRoot());

		vector<CD*>* catalog = parser.getCatalog();

		for (vector<CD*>::iterator it = catalog->begin() ; it != catalog->end(); ++it)
			cout << "------------------------------------------\n" << **it;
		cout << "------------------------------------------\n" << endl;
	}else{
		cout<< "unable to parse file" << endl;
	}
}


 /*
 * Main function that can be used to parse and print one CD.
 * It takes as argument a string which is the path to the xml file.
 */
 /*int main(int argc, char* argv[]){
	CDParser parser;

	if(parser.loadFile(argv[1])){
		CD cd = parser.parseCD(parser.getRoot());

		cout << cd;
	}
}*/
