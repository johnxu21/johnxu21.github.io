//============================================================================
// Name        : CD.h
// Author      : Quinten Soetens
// Version     :
// Description : This code is written as an example solution for the exercises given in the course
//				 Project Software Engineering for the first year bachelor students at Universiteit Antwerpen
//============================================================================

#ifndef CD_H_
#define CD_H_

#include <iostream>
#include <algorithm>

using namespace std;

class CD {
private:
	string _title;
	string _artist;
	string _company;
	string _country;
	double _price;
	int _year;
	bool isValidYear();
	bool isValidPrice();
	bool isValidString(const string& str);
public:
	CD();
	virtual ~CD();
	const string& getArtist() const;
	void setArtist(const string& artist);
	const string& getCompany() const;
	void setCompany(const string& company);
	const string& getCountry() const;
	void setCountry(const string& country);
	double getPrice() const;
	void setPrice(double price);
	const string& getTitle() const;
	void setTitle(const string& title);
	int getYear() const;
	void setYear(int year);

	bool isConsistent();

	friend ostream& operator<<(ostream& out, const CD& obj){
		out << "TITLE: " << obj._title << "\n";
		out << "ARTIST: " << obj._artist << "\n";
		out << "COMPANY: " << obj._company << "\n";
		out << "COUNTRY: " << obj._country << "\n";
		out << "PRICE: " << obj._price << "\n";
		out << "YEAR: " << obj._year << "\n";
		return out;
	}

};



#endif /* CD_H_ */
